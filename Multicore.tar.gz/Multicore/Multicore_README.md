Currently the Multicore design only contains a working coherence protocol design. Will be interfaced with the data caches and the datapath in the future weeks.
